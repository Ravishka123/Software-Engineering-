
% Build matlabPyrTools
fprintf('Building matlabPyrTools...\n');
run(fullfile('matlabPyrTools', 'MEX', 'compilePyrTools.m'));

